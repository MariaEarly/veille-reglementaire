from datetime import datetime, timedelta
from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session

from .database import Base, engine, get_db
from .models import Item, Source
from .schemas import ItemOut, ManualItemCreate, SourceCreate, SourceOut
from .rss import parse_rss_feed
from .scoring import score_item
from .dedupe import make_duplicate_group

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Veille Aggregator MVP")


@app.get("/health")
def health():
    return {"status": "ok", "service": "veille-aggregator-mvp"}


@app.get("/sources", response_model=list[SourceOut])
def list_sources(db: Session = Depends(get_db)):
    return db.query(Source).order_by(Source.id.desc()).all()


@app.post("/sources", response_model=SourceOut)
def create_source(payload: SourceCreate, db: Session = Depends(get_db)):
    source = Source(**payload.model_dump())
    db.add(source)
    db.commit()
    db.refresh(source)
    return source


@app.post("/ingest/rss/{source_id}")
def ingest_rss(source_id: int, db: Session = Depends(get_db)):
    source = db.query(Source).filter(Source.id == source_id).first()
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    if source.source_type != "rss":
        raise HTTPException(status_code=400, detail="Source is not RSS")
    if not source.url:
        raise HTTPException(status_code=400, detail="Source has no URL")

    entries = parse_rss_feed(source.url)
    created = 0

    for entry in entries:
        duplicate_group = make_duplicate_group(entry["title"], entry.get("url"))
        exists = db.query(Item).filter(Item.duplicate_group == duplicate_group).first()
        if exists:
            continue

        item = Item(
            source_id=source.id,
            source_name=source.name,
            source_type=source.source_type,
            url=entry.get("url"),
            title=entry["title"],
            author=entry.get("author"),
            published_at=entry.get("published_at"),
            raw_text=entry.get("raw_text"),
            summary=entry.get("summary"),
            tags=None,
            score=score_item(entry["title"], entry.get("raw_text"), source.source_type),
            duplicate_group=duplicate_group,
            status="important" if score_item(entry["title"], entry.get("raw_text"), source.source_type) >= 40 else "new",
        )
        db.add(item)
        created += 1

    db.commit()
    return {"created": created, "parsed": len(entries)}


@app.post("/items/manual", response_model=ItemOut)
def add_manual_item(payload: ManualItemCreate, db: Session = Depends(get_db)):
    duplicate_group = make_duplicate_group(payload.title, payload.url)
    item = Item(
        source_name=payload.source_name,
        source_type=payload.source_type,
        url=payload.url,
        title=payload.title,
        author=None,
        published_at=datetime.utcnow(),
        raw_text=payload.raw_text,
        summary=payload.summary,
        tags=payload.tags,
        score=score_item(payload.title, payload.raw_text, payload.source_type),
        duplicate_group=duplicate_group,
        status="important" if score_item(payload.title, payload.raw_text, payload.source_type) >= 40 else "new",
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@app.get("/items", response_model=list[ItemOut])
def list_items(status: str | None = None, db: Session = Depends(get_db)):
    query = db.query(Item)
    if status:
        query = query.filter(Item.status == status)
    return query.order_by(Item.published_at.desc().nullslast(), Item.id.desc()).all()


@app.get("/digest")
def digest(days: int = 7, db: Session = Depends(get_db)):
    since = datetime.utcnow() - timedelta(days=days)
    items = (
        db.query(Item)
        .filter((Item.published_at == None) | (Item.published_at >= since))
        .order_by(Item.score.desc(), Item.published_at.desc().nullslast())
        .all()
    )

    return {
        "period_days": days,
        "count": len(items),
        "top_items": [
            {
                "title": item.title,
                "source_name": item.source_name,
                "score": item.score,
                "summary": item.summary,
                "url": item.url,
            }
            for item in items[:20]
        ],
    }
