# Veille Aggregator MVP

MVP d'agrégateur de veille en Python avec FastAPI et SQLite.

## Fonctionnalités
- Gestion des sources
- Ingestion RSS
- Ajout manuel d'items
- Déduplication simple
- Scoring simple
- Digest quotidien/hebdo
- Stub Gmail à brancher ensuite

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Endpoints principaux
- `GET /health`
- `GET /sources`
- `POST /sources`
- `POST /ingest/rss/{source_id}`
- `POST /items/manual`
- `GET /items`
- `GET /digest`

## Notes
- Base SQLite locale: `veille.db`
- Le scoring et la déduplication sont volontairement simples pour une V1
- Le connecteur Gmail est un stub dans `app/gmail_stub.py`
