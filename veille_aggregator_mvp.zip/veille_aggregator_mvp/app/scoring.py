from __future__ import annotations

KEYWORDS_HIGH = {
    "acpr", "amla", "eba", "esma", "sanctions", "lcb-ft", "tracfin", "mica", "dora", "fraud"
}


def score_item(title: str, raw_text: str | None = None, source_type: str | None = None) -> int:
    text = f"{title} {raw_text or ''}".lower()
    score = 10

    for kw in KEYWORDS_HIGH:
        if kw in text:
            score += 12

    if source_type == "email":
        score += 5
    if source_type == "manual":
        score += 3
    if len(text) > 3000:
        score += 5

    return min(score, 100)
